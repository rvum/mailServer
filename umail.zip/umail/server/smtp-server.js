/**
 * Created by rvum on 2017/3/5.
 */
exports.smtpserver=function(){
    var net = require("net");
    var HOST = '192.243.113.157';
    var PORT = 25;
    console.info('Now create Server');
// console.info();
    var operation = [];
    var msg;
    var dataMessage=[];
    var maildata={};
    var server = net.createServer(function (sock) {
        sock.write("220 newmx.rvum.org MX umail Mail Server\r\n");
        operation.push("220 newmx.rvum.org MX umail Mail Server");
        sock.on('data', function (data) {
            var dataStr = data.toString();
            console.log(dataStr);
            var operationLast = operation.pop();
            if (dataStr==="DATA\r\n") {
                msg = "DATA";
            }else{
                var datatmp = "";
                datatmp = dataStr;
                msg = datatmp.split(" ")[0];
                console.log(dataStr)
            }
            if(dataStr==="QUIT\r\n"){
                sock.end();
            }

            /*if(operationLast === "354 End data with <CR><LF>.<CR><LF>" && dataStr=="."){
             console.log("stop!!!!");
             var datastream = dataMessage.join("");

             var simpleParser = require('mailparser').simpleParser;
             simpleParser(datastream, function(err, mail){
             console.log(mail.headers);
             // console.log(mail.from);
             });
             sock.write("250 Ok:queued as\r\n");
             sock.end();
             }*/
            if(operationLast === "354 End data with <CR><LF>.<CR><LF>"){
                dataMessage.push(dataStr);
                console.log("datastr:"+dataStr);
                operation.push("354 End data with <CR><LF>.<CR><LF>");
                console.log("stop!!!!");
                var datastream = dataMessage.join("");

                var simpleParser = require('mailparser').simpleParser;
                simpleParser(datastream, function(err, mail){
                    console.log(mail.text);
                    console.log(mail.headers.get('subject'));
                    console.log(mail.headers.get('from').value[0].address);
                    console.log(mail.headers.get('to').value[0].address);
                    maildata.subject=mail.headers.get('subject');
                    maildata.from=mail.headers.get('from').value[0].address;
                    maildata.to=mail.headers.get('to').value[0].address;
                    maildata.content=mail.text;
                });
                sock.write("250 Ok:queued as\r\n");
                sock.end();
                return maildata;
            }

            console.log(msg);
            if(msg==="DATA" && operationLast ==="250 Ok"){
                console.log("lkjlkj");
                dataHandle();
            }
            else if (msg === "EHLO") {
                heloHandle();
            }
            else if (msg === "MAIL" && operationLast ==="250 newmx.rvum.org") {
                mailHandle();
            }
            else if (msg === "RCPT" && operationLast ==="250 Ok") {
                rcptHandle();
            }

            function heloHandle() {
                console.log("111");
                sock.write("250 newmx.rvum.org\r\n");
                operation.push("250 newmx.rvum.org");
            }

            function mailHandle() {
                console.log("222");
                sock.write("250 Ok\r\n");
                operation.push("250 Ok");
            }

            function rcptHandle() {
                console.log("333");
                sock.write("250 Ok\r\n");
                operation.push("250 Ok");
            }

            function dataHandle() {
                console.log("444");
                sock.write("354 End data with <CR><LF>.<CR><LF>\r\n");
                operation.push("354 End data with <CR><LF>.<CR><LF>");
            }
        })

    });
    server.on('listening', function () {
        console.log("服务器已绑定");
    });
    server.listen(PORT, HOST);
};


