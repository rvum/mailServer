/**
 * Created by rvum on 2017/3/5.
 */
exports.smtp = function (sender, rcpt, subject, content) {
    var net = require("net");
    var mx_record_map = {
        "outlook.com": "mx4.hotmail.com",
        "qq.com": "mx1.qq.com",
        "163.com": "163mx01.mxmail.netease.com"
    };
    var domain_address = rcpt.split("@")[1];

    var HOST = mx_record_map[domain_address];
    var PORT = 25;
// console.info('Now create Server');
// console.info();

    var client = net.connect(PORT, HOST, function () {
        // console.log('Client connected...');
        console.info();
    });
    var operationing = [];

    client.on('data', function (data) {
        // console.log("data------------");
        var dataStr = data.toString();
        console.log(dataStr);
        var msg = !/([^ ]+)$/.test(dataStr) || RegExp.$1;
        var code = (dataStr.match(/^\d+/g) || [""])[0];
        // console.log("msg: "+msg);
        // console.log("code: "+code);

        var helo = new Buffer('EHLO rvum.org' + "\r\n");
        var ok = new Buffer('MAIL FROM: <' + sender + '> BODY=8BITMIME' + "\r\n");
        var rcpt = new Buffer('RCPT TO: <' + rcpt + '>' + "\r\n");
        var data_content = new Buffer('DATA' + "\r\n");


        if (code === "220") {
            // console.log("lkjlkj");
            heloHandle();

        }
        if (code === "250") {
            // console.log("000");
            var operationingLast = operationing.pop();
            console.log("operationingLast: " + operationingLast);
            if (operationingLast && operationingLast.indexOf("EHLO") >= 0) {
                console.log("111");
                okHandle();
            }
            if (operationingLast && operationingLast.indexOf("MAIL") >= 0) {
                console.log("222");
                rcptHandle();
            }
            if (operationingLast && operationingLast.indexOf("RCPT") >= 0) {
                console.log("333");
                dataHandle();
            }
            if (operationingLast && operationingLast.indexOf("DATA") >= 0) {
                console.log("444");
                endHandle();
            }

        }
        if (code === "354") {
            endDataHandle();
            function endDataHandle() {
                var content_base64 = new Buffer(content, "base64");
                var content_utf8 = content_base64.toString("utf8");
                var realData = new Buffer("From: test <" + sender + ">\r\n"
                    + "To: <" + rcpt + ">\r\n"
                    + "Subject: " + subject + "\r\n"
                    + "MIME-Version: 1.0\r\n"
                    + "Content-Type: multipart/alternative;\r\n"
                    + content_utf8 + "\r\n"
                    + ".\r\n");
                var realData2 = new Buffer("From: test <" + sender + ">\r\n"
                    + "To: <" + rcpt + ">\r\n"
                    + "Subject: " + subject + "\r\n"
                    + "MIME-Version: 1.0\r\n"
                    + "Content-Type: multipart/mixed;boundary=\"--=_Part=\"\r\n"
                    + "\r\n"
                    + "This is a multi-part message in MIME format.\r\n"
                    + "\r\n\r\n"
                    + "----=_Part=\r\n"
                    + "Content-Type: text/plain; charset=utf8\r\n"
                    + "Content-Transfer-Encoding: base64\r\n"
                    + "\r\n"
                    + content + "\r\n"
                    + "----=_Part=--\r\n"
                    + ".\r\n");

                /*var realData = new Buffer("From: test <test@rvum.org>\r\n"
                 +"To: <18756985134@163.com>\r\n"
                 +"Subject: test0004\r\n"
                 +"MIME-Version: 1.0\r\n"
                 +"Content-Type: multipart/alternative;\r\n" +
                 "boundary='--=_Part='\r\n"
                 +"\r\n"
                 +"hello this is rvum.org\r\n"
                 +".\r\n");*/

                client.write(realData2);
                operationing.push("data_content");
                client.end();
            }
        }


        function heloHandle() {
            client.write(helo);
            operationing.push(helo);
        }

        function okHandle() {
            client.write(ok);
            operationing.push(ok);
        }

        function rcptHandle() {
            client.write(rcpt);
            operationing.push(rcpt);
        }

        function dataHandle() {
            client.write(data_content);
            operationing.push(data_content);
        }

        function endHandle() {
            var end = new Buffer("quit" + "\r\n");
            client.write(end);
        }
    });

    client.on('end', function (data) {
        console.log(data);
        console.info("end");
    });

    client.on('error', function (err) {
        console.log(err);
    });
};
