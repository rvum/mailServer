/**
 * Created by rvum on 2017/4/15.
 */
var http = require('http');
var fs = require('fs');
var path = require('path');
var mime = require('./mime').types;
var querystring = require('querystring');
// var cookie = require('cookie');
var mysql = require('mysql');
// var formidable = require('formidable');//用于解析前端form表单文件数据
var postData = "";
// var serverIp = '192.243.113.157';
var serverIp = '127.0.0.1';
var serverPwd = 'newpassword';
var database = 'umail';
var io = require("socket.io")(8898);
var smtp = require("./server/smtp_client").smtp;
var smtpserver = require("./server/smtp-server");


console.log("http-server start!");

/**
 * 建立http服务器
 */
var server = http.createServer(function (req, res) {
    /**
     * 获取页面访问的路径（路由）及访问url的扩展名
     */
    var pathname = req.url;
    var extname = path.extname(pathname);
    extname = extname ? extname.slice(1) : 'unknown';
    console.log(pathname);

    /**
     * 重要！！！
     * node路由中编写socket.io的即时推送要这么写！！！
     */
    res.io = io;

    /**
     * 格式化时间
     * @returns {string}
     */
    function getNowFormateDate() {
        var date = new Date();
        var seperator1 = "-";
        var seperator2 = ":";
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        return (date.getFullYear() + seperator1 + month + seperator1 + strDate
        + " " + date.getHours() + seperator2 + date.getMinutes()
        + seperator2 + date.getSeconds());
    }

    /**
     * 路由是根目录跳转到登录
     */
    if (pathname === '/') {
        res.writeHead(200, {"Content-type": "application/json", "Access-Control-Allow-Origin": "*"});
        res.writeHeader(200, {'Content-Type': 'text/html'});
        fs.createReadStream('./client/index.html').pipe(res);
        console.log("visit /  at: " + getNowFormateDate());
    }
    /**
     * 路由为favicon.ico
     */
    else if (pathname === "/favicon.ico") {
        res.writeHead(200, {"Content-type": "application/json", "Access-Control-Allow-Origin": "*"});
        fs.createReadStream('./favicon.ico').pipe(res);
        console.log("visit favicon.ico  at: " + getNowFormateDate());
    }
    /**
     * 路由为robots.txt
     */
    else if (pathname === "/robots.txt") {
        res.writeHead(200, {"Content-type": "application/json", "Access-Control-Allow-Origin": "*"});
        res.end("");
        console.log("visit robots.txt  at: " + getNowFormateDate());
    }

    /**
     * 用户注册regeister.html
     */
    else if (pathname === "/register/") {
        console.log("用户注册!");
        postData = "";
        // 数据块接收中
        req.addListener("data", function (postDataChunk) {
            postData += postDataChunk;
        });

        req.addListener("end", function () {
            var oriData = querystring.parse(postData);
            var username = oriData.username;
            var password = oriData.password;
            var data = {username: username, password: password};
            console.log(data);
            var mysql = require("mysql");
            var connection = mysql.createConnection({
                host: serverIp,
                user: 'root',
                password: serverPwd,
                database: database
            });
            // console.log("lkjlj");
            connection.connect();

            connection.query('insert into user values( null,\"' + username + '\" ,\"' + password + '\",null)',
                function (err, rows, fields) {
                    // var result1 = {code: 0};
                    console.log(rows);
                    var result2 = {code: 1};
                    if (err && err.toString().indexOf("ER_DUP_ENTRY") >= 0) {
                        console.log("注册失败！");
                        res.writeHead(200, {"Content-type": "application/json", "Access-Control-Allow-Origin": "*"});
                        res.end(JSON.stringify(result2));
                        throw err;
                    } else if (err) {
                        throw err;
                    }
                    console.log(rows);
                    if (rows["insertId"]) {
                        console.log("注册成功");
                        var result = JSON.parse(JSON.stringify(rows));
                        result.code = 0;
                        // console.log(result);

                        res.writeHead(200, {"Content-type": "application/json", "Access-Control-Allow-Origin": "*"});
                        res.end(JSON.stringify(result));
                    }
                });
            connection.end();
        });
    }

    /**
     * 用户登录路由index.html
     */
    else if (pathname === "/login/") {
        console.log("用户登陆!");
        res.writeHead(200, {"Content-type": "application/json", "Access-Control-Allow-Origin": "*"});
        postData = "";
        // 数据块接收中
        req.addListener("data", function (postDataChunk) {
            postData += postDataChunk;
        });

        req.addListener("end", function () {
            var oriData = querystring.parse(postData);
            // console.log("表单data:"+data);
            var username = oriData.username;
            var password = oriData.password;
            var data = {username: username, password: password};
            console.log(data);
            var mysql = require("mysql");
            var connection = mysql.createConnection({
                host: serverIp,
                user: 'root',
                password: serverPwd,
                database: database
            });
            // console.log("lkjlj");
            connection.connect();
            var sql = 'select * from user where username=\"' + username + '\" && password=\"' + password + '\"';

            connection.query(sql,
                function (err, rows) {
                    console.log(rows);
                    if (err) throw err;
                    // var result1 = {code: 0};
                    var result2 = {code: 1};

                    // console.log('The solution is: ', rows);
                    if (rows.length) {
                        console.log("登录成功");
                        var result = JSON.parse(JSON.stringify(rows));
                        result[0].code = 0;
                        // console.log(result);
                        /*res.setHeader('Set-Cookie', cookie.serialize(String(managername), String(managerpassword), {
                         httpOnly: false,
                         maxAge: 60 * 60 * 24 * 7 // 1 week
                         }));*/
                        res.writeHead(200, {"Content-type": "application/json", "Access-Control-Allow-Origin": "*"});
                        res.end(JSON.stringify(result));
                    } else {
                        console.log("登录失败！");
                        res.writeHead(200, {"Content-type": "application/json", "Access-Control-Allow-Origin": "*"});
                        res.end(JSON.stringify(result2));
                    }
                });
            connection.end();
        });
    }

    /**
     * 用户发送邮件umail.html
     */
    else if (pathname === "/sendmail/") {
        console.log("用户发送邮件!");
        postData = "";
        // 数据块接收中
        req.addListener("data", function (postDataChunk) {
            postData += postDataChunk;
        });
        result1 = {code: 0};
        result2 = {code: 1};

        req.addListener("end", function () {
            var oriData = querystring.parse(postData);
            // console.log(oriData);
            var sqlInsert;
            var username = oriData["username"],
                subject = oriData["subject"],
                userid = oriData["userid"],
                content = oriData["content"],
                rcpt = oriData["rcpt"];
            var date = getNowFormateDate();
            smtp(username, rcpt, subject, content);
            var connection = mysql.createConnection({
                host: serverIp,
                user: 'root',
                password: serverPwd,
                database: database
            });
            connection.connect();

            if (username !== "" && rcpt !== "") {
                sqlInsert = 'insert into send values(null,' + '\"' + username + '\",\"' + rcpt + '\",\"' + content + '\",null,\"' + date
                    + '\",null,null,0,\"发件箱\",null,0)';
                connection.query(sqlInsert
                    , function (err, rows) {
                        console.log(rows);
                        if (err) {
                            res.writeHead(200, {
                                "Content-type": "application/json",
                                "Access-Control-Allow-Origin": "*"
                            });
                            res.end(JSON.stringify(result2));
                            throw err;
                        }
                        res.writeHead(200, {"Content-type": "application/json", "Access-Control-Allow-Origin": "*"});
                        res.end(JSON.stringify(result1));
                    });
            }
            connection.end();
        });
    }

    /**
     * 获取拟稿者所有公文documents.html
     */
    else if (pathname === "/documents/") {
        console.log("所有公文获取！");
        postData = "";
        req.addListener("data", function (postDataChunk) {
            postData += postDataChunk;
        });
        result1 = {code: 0};
        result2 = {code: 1};
        req.addListener("end", function () {
            var oriData = querystring.parse(postData);
            var username = oriData["username"];
            var sql = 'select * from document where name=\"' + username + '\"';
            var connection = mysql.createConnection({
                host: serverIp,
                user: 'root',
                password: serverPwd,
                database: database
            });
            if (username !== "") {
                console.log(sql);
                connection.query(sql, function (err, rows, fields) {
                    if (err) throw err;
                    if (rows.length === 0) {
                        res.writeHead(200, {
                            "Content-type": "application/json",
                            "Access-Control-Allow-Origin": "*"
                        });
                        res.end(JSON.stringify(result2));
                    } else if (rows.length > 0) {
                        res.writeHead(200, {
                            "Content-type": "application/json",
                            "Access-Control-Allow-Origin": "*"
                        });
                        res.end(JSON.stringify(rows));
                    }
                });
                connection.end();
            }


        })
    }

    /**
     * 初级审核者获取需审核公文primary.html
     */
    else if (pathname === "/primary/") {
        console.log("初级审核者获取需审核公文!");
        postData = "";
        req.addListener("data", function (postDataChunk) {
            postData += postDataChunk;
        });
        result1 = {code: 0};
        result2 = {code: 1};
        req.addListener("end", function () {
            var oriData = querystring.parse(postData);
            var primaryname = oriData["primaryname"];
            var sql = 'select * from document where primarystate=0';
            var connection = mysql.createConnection({
                host: serverIp,
                user: 'root',
                password: serverPwd,
                database: database
            });
            connection.connect();
            connection.query(sql, function (err, rows, fields) {
                console.log(rows);
                if (err) throw err;
                if (rows.length === 0) {
                    res.writeHead(200, {
                        "Content-type": "application/json",
                        "Access-Control-Allow-Origin": "*"
                    });
                    res.end(JSON.stringify(result2));
                } else if (rows.length > 0) {
                    res.writeHead(200, {
                        "Content-type": "application/json",
                        "Access-Control-Allow-Origin": "*"
                    });
                    res.end(JSON.stringify(rows));
                }
            });
            connection.end();
        });
    }

    /**
     * 高级审核者获取需审核公文senior.html
     */
    else if (pathname === "/senior/") {
        console.log("高级审核者获取需审核公文!");
        postData = "";
        req.addListener("data", function (postDataChunk) {
            postData += postDataChunk;
        });
        result1 = {code: 0};
        result2 = {code: 1};
        req.addListener("end", function () {
            var oriData = querystring.parse(postData);
            var seniorname = oriData["seniorname"];
            var sql = 'select * from document where seniorstate=0 and primarystate=1 ';
            var connection = mysql.createConnection({
                host: serverIp,
                user: 'root',
                password: serverPwd,
                database: database
            });
            connection.connect();
            connection.query(sql, function (err, rows, fields) {
                console.log(rows);
                if (err) throw err;
                if (rows.length === 0) {
                    res.writeHead(200, {
                        "Content-type": "application/json",
                        "Access-Control-Allow-Origin": "*"
                    });
                    res.end(JSON.stringify(result2));
                } else if (rows.length > 0) {
                    res.writeHead(200, {
                        "Content-type": "application/json",
                        "Access-Control-Allow-Origin": "*"
                    });
                    res.end(JSON.stringify(rows));
                }
            });
            connection.end();
        });
    }

    /**
     * 初级审核者提交审核
     */
    else if (pathname === "/primary_pass/") {
        console.log("初级审核者提交审核！");
        postData = "";
        req.addListener("data", function (postDataChunk) {
            postData += postDataChunk;
        });
        result1 = {code: 0};
        result2 = {code: 1};
        req.addListener("end", function () {
            var oriData = querystring.parse(postData);
            var documentid = oriData.documentid.split("_")[1],
                primarynote = oriData.primarynote,
                passstate = oriData.passstate,
                subject = oriData.subject;
            console.log("documentid:" + documentid);
            console.log("primarynote:" + primarynote);
            console.log("subject:" + subject);
            var connection = mysql.createConnection({
                host: serverIp,
                user: 'root',
                password: serverPwd,
                database: database
            });
            var state, primarystate, stateDescribe;
            if (passstate == 0) {
                state = 2;//初级审核者审核通过
                primarystate = 1;//0为默认，1为通过，2为不通过
                stateDescribe = "初级审核通过，高级审核中..."
            }

            if (passstate == 1) {
                state = 1;//初级审核者审核不通过
                primarystate = 2;//0为默认，1为通过，2为不通过
                stateDescribe = "初级审核未通过，请修改后重新发起提交！"
            }
            var sql = 'update document set primarynote=\"' + primarynote + '\",state=' + state + ',primarystate=' + primarystate + ' where documentid=' + documentid;
            console.log(sql);
            connection.connect();
            connection.query(sql, function (err, rows, fields) {
                if (err) {
                    res.writeHead(200, {
                        "Content-type": "application/json",
                        "Access-Control-Allow-Origin": "*"
                    });
                    res.end(JSON.stringify(result2));
                    throw err;
                }

                res.writeHead(200, {
                    "Content-type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                });
                /**
                 *
                 * @type {{subject: string, state: string, documentid: *}}
                 */
                /*var data = {
                 subject: "请假",
                 state: "初级审核者审核通过",
                 documentid: documentid
                 };
                 socket.emit('new_judge', data);*/
                /*io.on('connection', function (socket) {
                 var data = {
                 subject: "请假",
                 state: "初级审核者审核通过",
                 documentid:documentid
                 };
                 socket.emit('new_judge', data);

                 });*/

                var data = {
                    subject: subject,
                    stateDescribe: stateDescribe,
                    documentid: documentid
                };

                /**
                 * 重要！！！
                 * node路由中编写socket.io的即时推送要这么写！！！
                 */
                res.io.emit('new_judge', data);
                res.end(JSON.stringify(result1));
            });
            connection.end();
        });
    }

    /**
     * 高级审核者提交审核
     */
    else if (pathname === "/senior_pass/") {
        console.log("高级审核者提交审核！");
        postData = "";
        req.addListener("data", function (postDataChunk) {
            postData += postDataChunk;
        });
        result1 = {code: 0};
        result2 = {code: 1};
        req.addListener("end", function () {
            var oriData = querystring.parse(postData);
            var documentid = oriData.documentid.split("_")[1],
                seniornote = oriData.seniornote,
                passstate = oriData.passstate;
            console.log("documentid:" + documentid);
            console.log("seniornote:" + seniornote);
            var connection = mysql.createConnection({
                host: serverIp,
                user: 'root',
                password: serverPwd,
                database: database
            });
            var state, primarystate;
            if (passstate == 0) {
                state = 5;//高级审核者审核通过
                seniorstate = 1;//0为默认，1为通过，2为不通过
            }

            if (passstate == 1) {
                state = 4;//高级审核者审核不通过
                seniorstate = 2;//0为默认，1为通过，2为不通过
            }
            var sql = 'update document set seniornote=\"' + seniornote + '\",state=' + state + ',seniorstate=' + seniorstate + ' where documentid=' + documentid;
            console.log(sql);
            connection.connect();
            connection.query(sql, function (err, rows, fields) {
                if (err) {
                    res.writeHead(200, {
                        "Content-type": "application/json",
                        "Access-Control-Allow-Origin": "*"
                    });
                    res.end(JSON.stringify(result2));
                    throw err;
                }

                res.writeHead(200, {
                    "Content-type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                });
                res.end(JSON.stringify(result1));
            });
            connection.end();
        });
    }
    /**
     * 其他路由或未知路由
     */
    else {
        res.writeHeader(200, {'Content-Type': mime[extname], "Access-Control-Allow-Origin": "*"});
        fs.createReadStream("./client" + pathname).pipe(res);
        console.log("visit other at: " + getNowFormateDate());
    }
});

/**
 * 监听http服务器的8090端口
 */
server.listen(8899);

/**
 * 全局error捕获
 */
process.on('uncaughtException', function (err) {
    //打印出错误
    console.log(err);
    //打印出错误的调用栈方便调试
    console.log(err.stack);
    var date = new Date();
    var time = date.getFullYear() + "/" + parseInt(date.getMonth() + 1) + "/" + date.getDate() + " " +
        date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
    console.log(time);
});