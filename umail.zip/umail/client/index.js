/**
 * Created by rvum on 2017/4/15.
 */
// require("./skin/workflow.css");
// require("./socket.io.js");
var serverAddress = "http://127.0.0.1:8899/";

if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
    var msViewportStyle = document.createElement('style');
    msViewportStyle.appendChild(
        document.createTextNode(
            '@-ms-viewport{width:auto!important}'
        )
    );
    document.querySelector('head').appendChild(msViewportStyle)
}

$(document).ready(
    /**
     * 初始化状态
     */
    /*function(){
     var local_url = window.location.pathname.slice(1);
     // console.log(local_url);
     var name = getCookie("name");
     var type = getCookie("type");
     var url,data;
     /!**
     * 对初级审核者页面进行权限控制
     *!/
     if (local_url === "primary.html") {
     if (name && type==="option1") {
     var str = "已登录用户：" + name;
     $("#partname").html(str + '<span class="caret"></span>');
     $("#partname-2").html(str + '<span class="caret"></span>');

     /!**
     * 初级审核者页面初始化
     *!/
     url = serverAddress+"primary/";
     data = "primaryname="+name;
     $.ajax({
     url:url,
     method:"POST",
     data:data
     }).done(function(text){
     // console.log(text);
     for (var i = 0; i < text.length; i++) {
     var documentid = text[i]["documentid"];
     var document_id = "document_"+documentid;
     var primarynote_id = "primarynoteid_"+documentid;
     var pass_id = "pass_"+documentid;
     var failed_id = "failed_"+documentid;
     var subject_id = "subject_"+documentid;
     // console.log("document_id: "+document_id);
     $("#primary_table").append("<tr><td id='"+document_id+"'>" + (i+1) + "</td><td><table " +
     "class='table table-striped table-hover table-bordered'><tr><th>项目</th>" +
     "<th>详细情况</th></tr><tr><td>姓名</td><td>" + text[i]["name"] + "</td><tr><td>主题</td><td id='"+subject_id+"'>"
     + text[i]["subject"] + "</td></tr><tr><td>内容</td><td>"+text[i]["content"]+"</td></tr>" +
     "<tr><td>时间</td><td>"+text[i]["time"]+"</td></tr><tr><td>其他</td><td></td></tr></table></td>" +
     "<td><input type='text' id='"+primarynote_id+"'></td><td><a href='#' id='"+pass_id+"'>审批通过</a></td><td><a href='#' id='"+failed_id+"'>审批不通过</a></td></tr>"
     );

     /!**
     * 初级审核者提交审核
     *!/
     $("#"+pass_id).click(function(event){
     event.preventDefault();
     var pass_this = this;
     var documentid = $(this).parent().parent().children("td").get(0).id;
     var primarynote_id = $(this).parent().prev().children("input").get(0).id;
     var id = documentid.split("_")[1];
     var subject = $("#subject_"+id).text();
     // console.log(subject);
     pass_handle(documentid,primarynote_id,pass_this,subject);
     });
     function pass_handle(documentid,primarynote_id,pass_this,subject){
     // console.log(subject);
     var primarynote = $("#"+primarynote_id).val()||"无";
     var data = "documentid="+documentid+"&primarynote="+primarynote+"&passstate=0&subject="+subject,
     url = serverAddress+"primary_pass/";
     $.ajax({
     method:"POST",
     data:data,
     url:url
     }).done(function(text) {
     if(text["code"]===0){
     $(pass_this).unbind("click");
     $(pass_this).addClass("unbind");
     $(pass_this).html("审核已通过");
     $($(pass_this).parent().next().children("a").get(0)).addClass("cancel_click").unbind("click");
     }
     })
     }
     /!**
     * 初级审核者提交审核
     *!/
     $("#"+failed_id).click(function(event){
     event.preventDefault();
     var failed_this = this;
     var documentid = $(this).parent().parent().children("td").get(0).id;
     var primarynote_id = $(this).parent().prev().prev().children("input").get(0).id;
     var id = documentid.split("_")[1];
     var subject = $("#subject_"+id).text();
     failed_handle(documentid,primarynote_id,failed_this,subject);
     });
     function failed_handle(documentid,primarynote_id,failed_this,subject){
     var primarynote = $("#"+primarynote_id).val()||"无";
     var data = "documentid="+documentid+"&primarynote="+primarynote+"&passstate=1&subject="+subject,
     url = serverAddress+"primary_pass/";
     $.ajax({
     method:"POST",
     data:data,
     url:url
     }).done(function(text) {
     if(text["code"]===0){
     $(failed_this).unbind("click");
     $(failed_this).addClass("unbind_failed");
     $(failed_this).html("审核未通过");
     $($(failed_this).parent().prev().children("a").get(0)).addClass("cancel_click").unbind("click");
     }
     })
     }
     }

     })

     } else {
     alert("请登录！");
     window.location.href = serverAddress;
     }
     }
     /!**
     * 对高级审核页面进行权限控制
     *!/
     else if(local_url === "senior.html") {
     if (name && type==="option2") {
     var str2 = "已登录用户：" + name;
     $("#partname").html(str2 + '<span class="caret"></span>');
     $("#partname-2").html(str2 + '<span class="caret"></span>');
     /!**
     * 高级审核者页面初始化
     *!/
     url = serverAddress+"senior/";
     data = "seniorname="+name;
     $.ajax({
     url:url,
     method:"POST",
     data:data
     }).done(function(text){
     // console.log(text);
     for (var i = 0; i < text.length; i++) {
     var documentid = text[i]["documentid"];
     var document_id = "document_"+documentid;
     var seniornote_id = "seniornoteid_"+documentid;
     var pass_id = "pass_"+documentid;
     var failed_id = "failed_"+documentid;
     // console.log("document_id: "+document_id);
     $("#senior_table").append("<tr><td id='"+document_id+"'>" + (i+1) + "</td><td><table " +
     "class='table table-striped table-hover table-bordered'><tr><th>项目</th>" +
     "<th>详细情况</th></tr><tr><td>姓名</td><td>" + text[i]["name"] + "</td><tr><td>主题</td><td>"
     + text[i]["subject"] + "</td></tr><tr><td>内容</td><td>"+text[i]["content"]+"</td></tr>" +
     "<tr><td>时间</td><td>"+text[i]["time"]+"</td></tr><tr><td>其他</td><td></td></tr></table></td>" +
     "<td><input type='text' id='"+seniornote_id+"'></td><td><a href='#' id='"+pass_id+"'>审批通过</a></td><td><a href='#' id='"+failed_id+"'>审批不通过</a></td></tr>"
     );

     /!**
     * 高级审核者提交审核
     *!/
     $("#"+pass_id).click(function(){
     event.preventDefault();
     var pass_this = this;
     var documentid = $(this).parent().parent().children("td").get(0).id;
     var seniornote_id = $(this).parent().prev().children("input").get(0).id;
     pass_handle(documentid,seniornote_id,pass_this);
     });
     function pass_handle(documentid,seniornote_id,pass_this){
     var seniornote = $("#"+seniornote_id).val()||"无";
     var data = "documentid="+documentid+"&seniornote="+seniornote+"&passstate=0",
     url = serverAddress+"senior_pass/";
     $.ajax({
     method:"POST",
     data:data,
     url:url
     }).done(function(text) {
     if(text["code"]===0){
     $(pass_this).unbind("click");
     $(pass_this).addClass("unbind");
     $(pass_this).html("审核已通过");
     $($(pass_this).parent().next().children("a").get(0)).addClass("cancel_click").unbind("click");
     }
     })
     }
     /!**
     * 高级审核者提交审核
     *!/
     $("#"+failed_id).click(function(){
     event.preventDefault();
     var failed_this = this;
     var documentid = $(this).parent().parent().children("td").get(0).id;
     var seniornote_id = $(this).parent().prev().prev().children("input").get(0).id;
     failed_handle(documentid,seniornote_id,failed_this);
     });
     function failed_handle(documentid,seniornote_id,failed_this){
     var seniornote = $("#"+seniornote_id).val()||"无";
     var data = "documentid="+documentid+"&seniornote="+seniornote+"&passstate=1",
     url = serverAddress+"senior_pass/";
     $.ajax({
     method:"POST",
     data:data,
     url:url
     }).done(function(text) {
     if(text["code"]===0){
     $(failed_this).unbind("click");
     $(failed_this).addClass("unbind_failed");
     $(failed_this).html("审核未通过");
     $($(failed_this).parent().prev().children("a").get(0)).addClass("cancel_click").unbind("click");
     }
     })
     }
     }

     })

     } else {
     alert("请登录！");
     window.location.href = serverAddress;
     }


     }
     /!**
     * 对拟稿者所有公文页面进行权限控制，并对该页面进行初始化！
     *!/
     else if(local_url === "documents.html") {
     if (name && type==="option0") {
     var str3 = "已登录用户：" + name;
     $("#partname").html(str3 + '<span class="caret"></span>');
     $("#partname-2").html(str3 + '<span class="caret"></span>');

     //如果已经登录，则初始化所有公文页面
     data = "username="+name;
     url = serverAddress+"documents/";
     $.ajax({
     url:url,
     method:"POST",
     data:data
     }).done(function(text){
     var document_state,pass_state;
     for (var i = 0; i < text.length; i++) {
     if(text[i]["primarynote"]===null) text[i]["primarynote"]="无";
     if(text[i]["seniornote"]===null) text[i]["seniornote"]="无";
     if(text[i]["state"]===0){
     document_state = "未通过";
     pass_state = "初级审核者审核中";
     }
     if(text[i]["state"]===1){
     document_state = "未通过";
     pass_state = "初级审核者审核不通过";
     }
     if(text[i]["state"]===2){
     document_state = "未通过";
     pass_state = "初级审核者审核通过";
     }
     if(text[i]["state"]===3){
     document_state = "未通过";
     pass_state = "高级审核者审核中";
     }
     if(text[i]["state"]===4){
     document_state = "未通过";
     pass_state = "高级审核者审核中=不通过";
     }
     if(text[i]["state"]===5){
     document_state = "通过";
     pass_state = "高级审核者审核通过";
     }
     $("#documents_table").append("<tr><td>" + (i+1) + "</td><td>" + text[i]["subject"] + "</td><td>" + text[i]["content"]+ "</td><td>" + text[i]["time"]+ "</td><td>" + document_state+ "</td><td>" + pass_state + "</td><td>" + text[i]["primarynote"]+ "</td><td>" + text[i]["seniornote"]+ "</td></tr>");
     }
     })
     } else {
     alert("请登录！");
     window.location.href = serverAddress;
     }
     }

     /!**
     *
     *!/
     else if(local_url === "user.html") {
     if (name && type==="option0") {
     var str5 = "已登录用户：" + name;
     $("#partname").html(str5 + '<span class="caret"></span>');
     $("#partname-2").html(str5 + '<span class="caret"></span>');
     window.Notification.requestPermission();
     /!**
     *
     *!/
     var socket = io.connect('http://localhost:2018');
     socket.on('new_judge', function (data) {
     // console.log("subject:"+data["subject"]);
     // console.log("stateDescribe:"+data.stateDescribe);
     // console.log("documentid:"+data.documentid);
     var subject = data["subject"];
     var stateDescribe = data["stateDescribe"];
     var title = "您主题为："+subject+"有新的审核状态！";
     var options ={
     body:stateDescribe,
     icon:'logo.gif'
     };
     var notification = new Notification(title,options);
     notification.onshow=function(){

     }

     });
     }else{
     alert("请登录！");
     window.location.href = serverAddress;
     }
     }
     else if(local_url ==="login.html"||local_url===""){

     }
     else{
     if(name){
     var str4 = "已登录用户：" + name;
     $("#partname").html(str4 + '<span class="caret"></span>');
     $("#partname-2").html(str4 + '<span class="caret"></span>');
     }else {
     alert("请登录！");
     window.location.href = serverAddress;
     }
     }
     },*/

    /**
     * 注册
     */
    $("#register").click(function (event) {
        event.preventDefault();
        var username = $("#username").val();
        var len = username.length;
        if (username.indexOf("@rvum.org") !== (len - 9)) {
            $("#wrong").html("*格式错误，请重新填写 !").addClass("wrongLogin");
        }else{
            var data = "username=" + username + "&password=" + $("#passwd").val();
            var url = serverAddress + "register/";
            $.ajax({
                method: "POST",
                url: url,
                data: data
            }).done(function (text) {
                    console.log(text);
                    if (text && text["code"] && text["code"] === 1) {
                        $("#wrong").html("*注册失败，请重新填写 !").addClass("wrongLogin");
                    } else if (text && text["code"] === 0) {
                        window.location.href = "./index.html";
                    }

                }
            )
        }

    }),
    /**
     * 登陆
     */
    $("#login_button").click(function (event) {
        event.preventDefault();
        var data = "username=" + $("#username").val() + "&password=" + $("#passwd").val();
        var url = serverAddress + "login/";
        console.log(data);
        console.log(url);
        $.ajax({
            method: "post",
            url: url,
            data: data
        }).done(function (text) {
                console.log(text);
                if (text && text["code"] && text["code"] === 1) {
                    $("#wrong").html("*密码错误 !").addClass("wrongLogin");
                } else if (text && text[0] && text[0]["code"] === 0) {
                    var code = text[0]["code"];
                    setCookie("name", text[0]["username"], 1);
                    setCookie("userid", text[0]["userid"], 1);
                    window.location.href = "./umail.html";

                }

            }
        )
    }),
    /**
     * 点击写信按钮，打开邮件编辑模态框
     */
    $(".glyphicon-pencil").click(function (event) {
        event.preventDefault();
        $(".modal-content").css("display","block");
    }),

    /**
     * 关闭邮件编辑模态框
     */
    $(".glyphicon-remove-circle").click(function(event){
        event.preventDefault();
        $(".modal-content").css("display","none");
    }),

    /**
     * 发送邮件
     */
    $("#send_button").click(function(event){
        event.preventDefault();
        var username = getCookie("name");
        var userid = getCookie("userid");
        var rcpt = $("#rcpter_man").val();
        var subject = $("#subject_content").val();
        var content_str = $("#content_input").val();
        var content = new Buffer(content_str,"utf8").toString("base64");

        var data = "username="+username+"&userid="+userid+"&rcpt="+rcpt+"&subject="+subject+"&content="+content;
        var url = serverAddress+"sendmail/";
        if(rcpt===""){
            alert("请输入收件人！")
        }else{
            $.ajax({
                url:url,
                method:"POST",
                data:data
            }).done(function(text){
                console.log(text);
            })
        }

    })
);


    /**
     * 拟稿者拟稿界面 监听上传按钮
     */
    $("#user_submit").click(function () {
        var name = $(".document_name").val();
        var subject = $(".document_subject").val();
        var time = $(".document_time").val();
        var content = $(".document_content").val();
        var data = "name=" + name + "&subject=" + subject + "&time=" + time + "&content=" + content;
        var url = serverAddress + "user/";
        $.ajax({
            method: "post",
            url: url,
            data: data
        }).done(function (text) {
            var code = text["code"];
            if (code === 0) {
                $("#alert_user").html("*保存成功！").css("display", "inline-block").css("color", "green");
                $("#user_submit").unbind("click");
            } else {
                $("#alert_user").html("*保存失败请重试！").addClass("wrong").css("display", "inline-block").css("color", "red");
            }
        })
    });


/**
 * 设置cookie信息
 * @param c_name
 * @param value
 * @param expiredays
 */
function setCookie(c_name, value, expiredays) {
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + expiredays);
    document.cookie = c_name + "=" + escape(value) +
        ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString())
}
/**
 * 删除cookie信息
 * @param c_name
 * @returns {string}
 */
function getCookie(c_name) {
    if (document.cookie.length > 0) {
        c_start = document.cookie.indexOf(c_name + "=");
        if (c_start != -1) {
            c_start = c_start + c_name.length + 1;
            c_end = document.cookie.indexOf(";", c_start);
            if (c_end == -1) c_end = document.cookie.length;
            return unescape(document.cookie.substring(c_start, c_end))
        }
    }
    return ""
}